// ============================================
// CONFIGURAÇÃO DO SUPABASE - ORIGINAL SYSTEM
// ============================================

export const supabaseConfig = {
  url: 'https://vqrwjassqebxjtnzppku.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZxcndqYXNzcWVieGp0bnpwcGt1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE1MjM2ODEsImV4cCI6MjA4NzA5OTY4MX0.CUteH_AHLkqdt6q-X-m8V5w_-GSM3kWHb87HbD0bsJc',
  serviceRoleKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZxcndqYXNzcWVieGp0bnpwcGt1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTUyMzY4MSwiZXhwIjoyMDg3MDk5NjgxfQ.0iJbfhNY7qTbJSNAUKV2cxitKimcIMB6_-QfmcCLH_8',
  projectId: 'vqrwjassqebxjtnzppku'
};

export default supabaseConfig;
